//This js file is utilized by the html files view, add, edit, and remove.

/* 
================================================================================================
GLOBAL Functions
================================================================================================
*/

//POST shit maybe (v = formData #MIGHT HAVE TO CHANGE DUE TO PASSING JSON DATA, so v might be = parsed JSON file)
//reconstructing JSON data received and passing it onto our <options> for choices
// might want received data PARSED
//might add another parameter variable such as p for passed value or s - selected value
// basically I will base the options for the next value based of the preceding value which will be passed on as p or s
//CHECK: if I could just have jsonObjID += <option> + v[i].actualJSONObj
function populateCollege(v){
    console.log("populateCollege() is running");
    var collegeID, collegeName, collegeAbbrv;
}
function populateDepartment(v, p){ //testing passed argument
    console.log("populateDepartment() is running");
    var deptID, deptName, deptAbrrv;
    var collegeID; //base the department to be shown by collegeID
    //var jsonObjHolder = v;
    collegeID = p;

    for (i in v){
        //if the previous collegeID is in this portion of the json obj, show the other options!
        if(collegeID == v[i].collegeID){ //might not work lmao
            deptID += "<option>" + deptID[i].deptID;
            deptName += "<option>" + deptName[i].deptName;
            deptAbrrv += "<option>" + deptAbrrv[i].deptAbrrv;
        }
        else{
            console.log("this shit not working");
        }
    }
    document.getElementById("populateDepartment").innerHTML = deptName;
}
function populateProgram(v){
    console.log("populateProgram() is running");
    var programID, programName, programAbbrv;
    var deptID;
}
function populateConcentration(v){
    console.log("populateConcentration() is running");
    var concentID, concentName, concentAbbrv; 
    var programID;
}
function populateCourse(v){
    console.log("populateCourse() is running");
    var courseID, prefixID, courseNum, title, courseDescription, credits; 
    var prereqs, prereqsGroupID, prereqsCourseID;
    //var courseIDHolder, prefixIDHolder, courseNumHolder, titleHolder, courseDescriptionHolder, creditsHolder, prereqsHolder; 
    //saving above for backup just incase the group of variables above it doesn't work

    //v = jsonData Obj
    for (i in v){
        courseID += "<option>" + courseID[i].courseID;
        prefixID += "<option>" + prefixID[i].prefixID;
        courseNum += "<option>" + courseNum[i].courseNum;
        title += "<option>" + title[i].title;
        courseDescription += "<option>" + courseDescription[i].courseDescription;
        credits += "<option>" + credits[i].credits;

        //prefix is a special case since it holds an array of objects    
        //pi = prereq items (the objects in the prereqs array)
        for (pi in v[i].prereqs){
            prereqsGroupID += prereqsGroupID[pi].groupID;
            prereqsCourseID += prereqsCourseID[pi].courseID; //if this doesn't work I may have to do another for loop to grab all values
            prereqs += "<option>" + prereqsGroupID + ":" + prereqsCourseID;
            //might not make the prereqs as a dropdown box
        }
        
    }

    //add these iD into <div id="id_name_that_corresponds"> in html as an <option> for their corresponding dropdown boxes
    //commented out code = probably not necessary lmao
    document.getElementById("populateCourse").innerHTML = courseID;
    document.getElementById("populatePrefix").innerHTML = prefixID;
    document.getElementById("populateCourseNum").innerHTML = courseNum;
    document.getElementById("populateTitle").innerHTML = title;
    document.getElementById("populateCourseDescription").innerHTML = courseDescription;
    document.getElementById("populateCredits").innerHTML = credits;
    document.getElementById("populatePrereqs").innerHTML = prereqs;
}

//Functions for revealing new dropdown lists
function showDroplistDepartment() {
    document.getElementById('department_box').style.display = "block";
}
function showDroplistProgram() {
    document.getElementById('program_box').style.display = "block";
}
function showDroplistConcentration() {
    document.getElementById('concentration_box').style.display = "block";
}
function showDroplistCourse() {
    document.getElementById('course_box').style.display = "block";
}
function showDroplist(section){
    if (section == "department"){
        document.getElementById('department_box').style.display = "block";
    } else if (section == "program"){
        document.getElementById('program_box').style.display = "block";
    } else if (section == "concentration"){
        document.getElementById('concentration_box').style.display = "block";
    } else if (section == "course"){
        document.getElementById('course_box').style.display = "block";
    }

}





/* 
================================================================================================
ADD PAGE ONLY Functions
================================================================================================
*/
function addCollege(v){
    console.log("add more shit here later lmao or delete this func");
}








/* 
================================================================================================
EDIT PAGE ONLY Functions
================================================================================================
*/
//Function for revealing input box when edit button is pressed
function showEditinput() {
    document.getElementById('editInputbox').style.display = "block";
}
function showEditinput2() {
    document.getElementById('editInputbox2').style.display = "block";
}
function showEditinput3() {
    document.getElementById('editInputbox3').style.display = "block";
}
function showEditinput4() {
    document.getElementById('editInputbox4').style.display = "block";
}





/* 
================================================================================================
REMOVE PAGE ONLY Functions
================================================================================================
*/
function removeCollege(){

}
function removeDepartment(){

}
function removeProgram(){

}
function removeCourse(){

}




